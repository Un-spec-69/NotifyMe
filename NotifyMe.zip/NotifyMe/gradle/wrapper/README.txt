Le fichier gradle-wrapper.jar est requis pour builder.
Il sera automatiquement téléchargé si vous utilisez Android Studio.
Sinon, téléchargez-le depuis :
https://github.com/gradle/gradle/raw/v8.6.0/gradle/wrapper/gradle-wrapper.jar
