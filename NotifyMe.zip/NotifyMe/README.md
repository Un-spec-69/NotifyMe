# 🔔 NotifyMe — Application Android

Créez et planifiez des notifications personnelles sur Android.

## Fonctionnalités

- ✅ Créer une notification avec **titre + message**
- ⏰ **Envoyer immédiatement** ou **planifier** à une date/heure précise
- 📋 **Liste** de toutes vos notifications (brouillons, planifiées, envoyées)
- ✏️ **Modifier** une notification non encore envoyée
- 🗑️ **Supprimer** une notification et annuler son alarme
- 🔁 **Résistante aux redémarrages** : les alarmes sont relancées au démarrage du téléphone

---

## Comment compiler l'APK

### Option 1 — Android Studio (recommandé, 5 min)

1. Ouvre **Android Studio**
2. `File → Open` → sélectionne ce dossier `NotifyMe`
3. Attends la synchronisation Gradle (téléchargement automatique des dépendances)
4. `Build → Build Bundle(s) / APK(s) → Build APK(s)`
5. L'APK apparaît dans `app/build/outputs/apk/debug/app-debug.apk`

### Option 2 — Ligne de commande

Prérequis : Java 17+ installé, Android SDK installé

```bash
# Linux/macOS
export ANDROID_HOME=/path/to/Android/Sdk
./gradlew assembleDebug

# Windows
set ANDROID_HOME=C:\Users\TU\AppData\Local\Android\Sdk
gradlew.bat assembleDebug
```

L'APK sera dans : `app/build/outputs/apk/debug/app-debug.apk`

### Installer sur ton téléphone

```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

Ou transfère le fichier `.apk` sur ton téléphone et ouvre-le
(il faut activer "Sources inconnues" dans Paramètres → Sécurité).

---

## Structure du projet

```
NotifyMe/
├── app/src/main/
│   ├── java/com/yann/notifyme/
│   │   ├── MainActivity.kt          # Écran principal
│   │   ├── model/NotificationItem.kt
│   │   ├── adapter/NotificationAdapter.kt
│   │   ├── receiver/AlarmReceiver.kt
│   │   ├── receiver/NotificationReceiver.kt
│   │   └── util/
│   │       ├── NotificationStore.kt  # Persistance JSON
│   │       ├── NotificationHelper.kt # Envoi de notifs
│   │       └── AlarmScheduler.kt     # Planification AlarmManager
│   └── res/layout/
│       ├── activity_main.xml
│       ├── item_notification.xml
│       └── dialog_create_notification.xml
```

## Permissions demandées

- `POST_NOTIFICATIONS` — pour afficher les notifications (Android 13+)
- `SCHEDULE_EXACT_ALARM` — pour envoyer à l'heure exacte
- `RECEIVE_BOOT_COMPLETED` — pour relancer les alarmes après redémarrage
