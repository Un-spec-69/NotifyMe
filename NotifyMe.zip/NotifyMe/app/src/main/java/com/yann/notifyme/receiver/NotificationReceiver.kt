package com.yann.notifyme.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.yann.notifyme.util.AlarmScheduler

class NotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            AlarmScheduler.rescheduleAll(context)
        }
    }
}
