package com.yann.notifyme.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.yann.notifyme.model.NotificationItem
import com.yann.notifyme.receiver.AlarmReceiver

object AlarmScheduler {

    const val EXTRA_NOTIF_ID = "notif_id"

    fun schedule(context: Context, item: NotificationItem) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra(EXTRA_NOTIF_ID, item.id)
        }
        val pi = PendingIntent.getBroadcast(
            context,
            item.id.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, item.scheduledTime, pi)
        } catch (e: SecurityException) {
            // Fallback si l'exact alarm n'est pas autorisée
            alarmManager.set(AlarmManager.RTC_WAKEUP, item.scheduledTime, pi)
        }
    }

    fun cancel(context: Context, item: NotificationItem) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            context,
            item.id.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pi)
    }

    fun rescheduleAll(context: Context) {
        val pending = NotificationStore.getAll(context).filter { it.isPending && it.isScheduled }
        pending.forEach { schedule(context, it) }
    }
}
