package com.yann.notifyme.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import com.yann.notifyme.R
import com.yann.notifyme.model.NotificationItem
import kotlin.math.abs

object NotificationHelper {

    private const val CHANNEL_ID = "notifyme_channel"
    private const val CHANNEL_NAME = "NotifyMe"

    fun createChannel(context: Context) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (manager.getNotificationChannel(CHANNEL_ID) == null) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications personnelles NotifyMe"
                enableVibration(true)
            }
            manager.createNotificationChannel(channel)
        }
    }

    fun sendNow(context: Context, item: NotificationItem) {
        createChannel(context)
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notifId = abs(item.id.hashCode())

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(item.title)
            .setContentText(item.message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(item.message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        manager.notify(notifId, notification)
        NotificationStore.markSent(context, item.id)
    }
}
