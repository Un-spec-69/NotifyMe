package com.yann.notifyme.model

import java.util.UUID

data class NotificationItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val message: String,
    val scheduledTime: Long,  // epoch millis, 0 = immediate
    var isSent: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
) {
    val isScheduled: Boolean get() = scheduledTime > 0
    val isPending: Boolean get() = !isSent && (scheduledTime == 0L || scheduledTime > System.currentTimeMillis())
}
