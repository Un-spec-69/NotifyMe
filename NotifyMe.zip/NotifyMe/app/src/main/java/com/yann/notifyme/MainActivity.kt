package com.yann.notifyme

import android.Manifest
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.yann.notifyme.adapter.NotificationAdapter
import com.yann.notifyme.model.NotificationItem
import com.yann.notifyme.util.AlarmScheduler
import com.yann.notifyme.util.NotificationHelper
import com.yann.notifyme.util.NotificationStore
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: NotificationAdapter
    private lateinit var tvEmpty: TextView
    private var scheduledCalendar: Calendar? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        NotificationHelper.createChannel(this)
        requestNotificationPermission()

        recyclerView = findViewById(R.id.recyclerView)
        tvEmpty = findViewById(R.id.tvEmpty)
        val fab: FloatingActionButton = findViewById(R.id.fab)

        adapter = NotificationAdapter(
            NotificationStore.getAll(this),
            onDelete = { item -> confirmDelete(item) },
            onSendNow = { item -> sendNow(item) },
            onEdit = { item -> showCreateDialog(item) }
        )

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        fab.setOnClickListener { showCreateDialog(null) }
        refreshList()
    }

    override fun onResume() {
        super.onResume()
        refreshList()
    }

    private fun refreshList() {
        val items = NotificationStore.getAll(this)
        adapter.updateItems(items)
        tvEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun showCreateDialog(existing: NotificationItem?) {
        scheduledCalendar = if (existing?.isScheduled == true)
            Calendar.getInstance().also { it.timeInMillis = existing.scheduledTime }
        else null

        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_create_notification, null)
        val etTitle = dialogView.findViewById<EditText>(R.id.etTitle)
        val etMessage = dialogView.findViewById<EditText>(R.id.etMessage)
        val rgSendMode = dialogView.findViewById<RadioGroup>(R.id.rgSendMode)
        val rbNow = dialogView.findViewById<RadioButton>(R.id.rbNow)
        val rbLater = dialogView.findViewById<RadioButton>(R.id.rbLater)
        val layoutSchedule = dialogView.findViewById<LinearLayout>(R.id.layoutSchedule)
        val tvScheduledTime = dialogView.findViewById<TextView>(R.id.tvScheduledTime)
        val btnPickDateTime = dialogView.findViewById<Button>(R.id.btnPickDateTime)

        existing?.let {
            etTitle.setText(it.title)
            etMessage.setText(it.message)
            if (it.isScheduled) {
                rbLater.isChecked = true
                layoutSchedule.visibility = View.VISIBLE
                updateScheduleLabel(tvScheduledTime)
            }
        }

        rgSendMode.setOnCheckedChangeListener { _, checkedId ->
            layoutSchedule.visibility = if (checkedId == R.id.rbLater) View.VISIBLE else View.GONE
        }

        btnPickDateTime.setOnClickListener {
            pickDateTime(tvScheduledTime)
        }

        val title = if (existing == null) "Nouvelle notification" else "Modifier la notification"
        val btnLabel = if (existing == null) "Créer" else "Enregistrer"

        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(dialogView)
            .setPositiveButton(btnLabel) { _, _ ->
                val t = etTitle.text.toString().trim()
                val m = etMessage.text.toString().trim()
                if (t.isEmpty() || m.isEmpty()) {
                    Toast.makeText(this, "Titre et message requis", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val sendLater = rbLater.isChecked
                val schedTime = if (sendLater) scheduledCalendar?.timeInMillis ?: 0L else 0L

                if (sendLater && schedTime == 0L) {
                    Toast.makeText(this, "Choisissez une date/heure", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (sendLater && schedTime <= System.currentTimeMillis()) {
                    Toast.makeText(this, "La date doit être dans le futur", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                if (existing == null) {
                    val item = NotificationItem(title = t, message = m, scheduledTime = schedTime)
                    NotificationStore.add(this, item)
                    if (!sendLater) {
                        NotificationHelper.sendNow(this, item)
                    } else {
                        AlarmScheduler.schedule(this, item)
                        Toast.makeText(this, "Notification planifiée ✅", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    // Cancel old alarm if any
                    AlarmScheduler.cancel(this, existing)
                    val updated = existing.copy(title = t, message = m, scheduledTime = schedTime, isSent = false)
                    NotificationStore.updateItem(this, updated)
                    if (!sendLater) {
                        NotificationHelper.sendNow(this, updated)
                    } else {
                        AlarmScheduler.schedule(this, updated)
                        Toast.makeText(this, "Notification mise à jour ✅", Toast.LENGTH_SHORT).show()
                    }
                }
                refreshList()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun pickDateTime(label: TextView) {
        val now = Calendar.getInstance()
        DatePickerDialog(this, { _, year, month, day ->
            TimePickerDialog(this, { _, hour, minute ->
                scheduledCalendar = Calendar.getInstance().apply {
                    set(year, month, day, hour, minute, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                updateScheduleLabel(label)
            }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
        }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun updateScheduleLabel(label: TextView) {
        scheduledCalendar?.let {
            val df = java.text.SimpleDateFormat("dd/MM/yyyy à HH:mm", Locale.FRANCE)
            label.text = "📅 ${df.format(it.time)}"
        }
    }

    private fun sendNow(item: NotificationItem) {
        AlarmScheduler.cancel(this, item)
        NotificationHelper.sendNow(this, item)
        Toast.makeText(this, "Notification envoyée !", Toast.LENGTH_SHORT).show()
        refreshList()
    }

    private fun confirmDelete(item: NotificationItem) {
        AlertDialog.Builder(this)
            .setTitle("Supprimer")
            .setMessage("Supprimer « ${item.title} » ?")
            .setPositiveButton("Supprimer") { _, _ ->
                AlarmScheduler.cancel(this, item)
                NotificationStore.delete(this, item.id)
                refreshList()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    1001
                )
            }
        }
        // Check exact alarm permission on Android 12+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (!alarmManager.canScheduleExactAlarms()) {
                AlertDialog.Builder(this)
                    .setTitle("Permission requise")
                    .setMessage("Pour envoyer des notifications à l'heure exacte, autorisez les alarmes exactes dans les paramètres.")
                    .setPositiveButton("Ouvrir les paramètres") { _, _ ->
                        val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:$packageName"))
                        startActivity(intent)
                    }
                    .setNegativeButton("Plus tard", null)
                    .show()
            }
        }
    }
}
