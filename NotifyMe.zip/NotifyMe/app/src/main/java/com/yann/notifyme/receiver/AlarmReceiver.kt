package com.yann.notifyme.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.yann.notifyme.util.AlarmScheduler
import com.yann.notifyme.util.NotificationHelper
import com.yann.notifyme.util.NotificationStore

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra(AlarmScheduler.EXTRA_NOTIF_ID) ?: return
        val item = NotificationStore.getAll(context).firstOrNull { it.id == id } ?: return
        if (!item.isSent) {
            NotificationHelper.sendNow(context, item)
        }
    }
}
