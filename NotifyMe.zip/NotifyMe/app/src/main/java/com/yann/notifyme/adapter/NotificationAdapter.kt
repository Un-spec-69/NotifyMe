package com.yann.notifyme.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.yann.notifyme.R
import com.yann.notifyme.model.NotificationItem
import java.text.SimpleDateFormat
import java.util.*

class NotificationAdapter(
    private var items: MutableList<NotificationItem>,
    private val onDelete: (NotificationItem) -> Unit,
    private val onSendNow: (NotificationItem) -> Unit,
    private val onEdit: (NotificationItem) -> Unit
) : RecyclerView.Adapter<NotificationAdapter.ViewHolder>() {

    private val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE)

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTitle: TextView = view.findViewById(R.id.tvTitle)
        val tvMessage: TextView = view.findViewById(R.id.tvMessage)
        val tvStatus: TextView = view.findViewById(R.id.tvStatus)
        val tvTime: TextView = view.findViewById(R.id.tvTime)
        val btnDelete: ImageButton = view.findViewById(R.id.btnDelete)
        val btnSendNow: ImageButton = view.findViewById(R.id.btnSendNow)
        val btnEdit: ImageButton = view.findViewById(R.id.btnEdit)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_notification, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvTitle.text = item.title
        holder.tvMessage.text = item.message

        when {
            item.isSent -> {
                holder.tvStatus.text = "✅ Envoyée"
                holder.tvStatus.setTextColor(Color.parseColor("#4CAF50"))
                holder.btnSendNow.visibility = View.GONE
                holder.btnEdit.visibility = View.GONE
            }
            item.isScheduled -> {
                holder.tvStatus.text = "⏰ Planifiée"
                holder.tvStatus.setTextColor(Color.parseColor("#FF9800"))
                holder.btnSendNow.visibility = View.VISIBLE
                holder.btnEdit.visibility = View.VISIBLE
            }
            else -> {
                holder.tvStatus.text = "📝 Brouillon"
                holder.tvStatus.setTextColor(Color.parseColor("#2196F3"))
                holder.btnSendNow.visibility = View.VISIBLE
                holder.btnEdit.visibility = View.VISIBLE
            }
        }

        holder.tvTime.text = if (item.isScheduled && !item.isSent) {
            "Envoi prévu : ${dateFormat.format(Date(item.scheduledTime))}"
        } else if (item.isSent) {
            "Créée le : ${dateFormat.format(Date(item.createdAt))}"
        } else {
            "Créée le : ${dateFormat.format(Date(item.createdAt))}"
        }

        holder.btnDelete.setOnClickListener { onDelete(item) }
        holder.btnSendNow.setOnClickListener { onSendNow(item) }
        holder.btnEdit.setOnClickListener { onEdit(item) }
    }

    override fun getItemCount() = items.size

    fun updateItems(newItems: MutableList<NotificationItem>) {
        items = newItems
        notifyDataSetChanged()
    }
}
