package com.yann.notifyme.util

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.yann.notifyme.model.NotificationItem

object NotificationStore {

    private const val PREFS_NAME = "notifyme_prefs"
    private const val KEY_NOTIFICATIONS = "notifications"
    private val gson = Gson()

    fun getAll(context: Context): MutableList<NotificationItem> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_NOTIFICATIONS, null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<NotificationItem>>() {}.type
        return gson.fromJson(json, type) ?: mutableListOf()
    }

    fun save(context: Context, items: List<NotificationItem>) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_NOTIFICATIONS, gson.toJson(items)).apply()
    }

    fun add(context: Context, item: NotificationItem) {
        val list = getAll(context)
        list.add(0, item)
        save(context, list)
    }

    fun markSent(context: Context, id: String) {
        val list = getAll(context)
        val idx = list.indexOfFirst { it.id == id }
        if (idx >= 0) {
            list[idx] = list[idx].copy(isSent = true)
            save(context, list)
        }
    }

    fun delete(context: Context, id: String) {
        val list = getAll(context)
        list.removeAll { it.id == id }
        save(context, list)
    }

    fun updateItem(context: Context, updated: NotificationItem) {
        val list = getAll(context)
        val idx = list.indexOfFirst { it.id == updated.id }
        if (idx >= 0) {
            list[idx] = updated
            save(context, list)
        }
    }
}
